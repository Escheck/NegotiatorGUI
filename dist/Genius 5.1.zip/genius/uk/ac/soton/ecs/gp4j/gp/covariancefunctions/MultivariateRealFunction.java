package uk.ac.soton.ecs.gp4j.gp.covariancefunctions;

public interface MultivariateRealFunction {

	double evaluate(double[] x);

}
