package negotiator.utility;


import negotiator.Bid;
import negotiator.issue.Objective;
import negotiator.issue.ValueDiscrete;
import negotiator.xml.SimpleElement;

public class EvaluatorNSP implements Evaluator{

	public double getWeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setWeight(double wt) {
		// TODO Auto-generated method stub
		
	}

	public void lockWeight() {
		// TODO Auto-generated method stub
		
	}

	public void unlockWeight() {
		// TODO Auto-generated method stub
		
	}

	public boolean weightLocked() {
		// TODO Auto-generated method stub
		return false;
	}

	public Double getEvaluation(UtilitySpace uspace, Bid bid, int index)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public EVALUATORTYPE getType() {
		// TODO Auto-generated method stub
		return null;
	}

	public void loadFromXML(SimpleElement pRoot) {
		// TODO Auto-generated method stub
		
	}

	public SimpleElement setXML(SimpleElement evalObj) {
		// TODO Auto-generated method stub
		return null;
	}

	public String isComplete(Objective whichObjective) {
		// TODO Auto-generated method stub
		return null;
	}

	public Double getCost(UtilitySpace uspace, Bid bid, int index)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public void showStatistics() {
		// TODO Auto-generated method stub
		
	}
	
	public EvaluatorNSP clone()
	{
		
		int x = 1/0; //this method is not implemented, so force an exception.
		return null;
	}

}
