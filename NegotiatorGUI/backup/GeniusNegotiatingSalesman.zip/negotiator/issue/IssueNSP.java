package negotiator.issue;

import java.util.ArrayList;

import NSPClasses.NSPCity;
import NSPClasses.ValueNSP2;


public class IssueNSP extends Issue {
	
	ArrayList<ValueNSP2> issueValues;
	NSPCity theCity; //each issue corresponds to a city.
	
	public IssueNSP(String name, int issueNumber, NSPCity city){
		super(name, issueNumber);
		theCity = city;
	}
	
}
