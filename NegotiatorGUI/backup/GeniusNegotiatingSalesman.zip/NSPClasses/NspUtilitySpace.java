package NSPClasses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import negotiator.issue.IssueNSP;
import negotiator.issue.Objective;
import negotiator.utility.Evaluator;
import negotiator.utility.UtilitySpace;

public class NspUtilitySpace extends UtilitySpace {
	
	private Map<Objective, Evaluator> fEvaluators;  //BE CAREFUL! SUPERCLASS FIELD HAS THE SAME NAME
	 
	public NspUtilitySpace(NSPGraphFilter theGraph){
		
		fEvaluators = new HashMap<Objective, Evaluator>();
		
		//first fill the list of objectives
		ArrayList<Objective> objectives = new ArrayList<Objective>();
		int i=0;
		for(NSPCity city : theGraph.getMyInterchangeableCities()){			
			objectives.add(new IssueNSP(Integer.toString(i), i, city));
			i++;
		}
		
		//then fill the map that assigns evaluators to objectives.
    	for (Objective obj:objectives) {
    		Evaluator eval =  DefaultEvaluator(obj);
    		fEvaluators.put(obj, eval);
    	}
		
	}
	
	
	
	
	
	
	
	//A Bid is interpreted as follows: each city is an issue, and each agent is a value. Note however that issues are no longer linearly additive.
	//alternatively, we can interpret the space as having only one issue, and each value is an assignment of cities.
	
	
	
	
}
