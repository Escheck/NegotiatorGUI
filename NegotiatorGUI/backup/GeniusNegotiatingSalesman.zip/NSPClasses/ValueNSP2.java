package NSPClasses;

import negotiator.AgentID;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Value;


public class ValueNSP2 extends Value{

	AgentID owner;
	
	//Constructor
	ValueNSP2(AgentID _owner){
		owner = _owner;
	}
	
	// Class methods
	public ISSUETYPE getType() {
		return ISSUETYPE.NSP;
	}
	
	public AgentID getValue() {
		return owner;
	}
	
	public String toString() {
		return owner.toString();
	}
	
	
	public boolean equals(Object pObject) {
		
		if(pObject instanceof ValueNSP2) {
			
			ValueNSP2 val = (ValueNSP2)pObject;
			return  owner.equals(val.getValue());
		
		} else if(pObject instanceof AgentID){
			
			AgentID val = (AgentID) pObject;
			return owner.equals(val);
		
		} else
			return false;
	}
	
	
	
}
