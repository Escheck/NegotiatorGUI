package NSPClasses;

public class NSPCity {
	
	//coordinates
	int x;
	int y;
	
	public NSPCity(int _x, int _y){
		x = _x;
		y = _y;
	}
	
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}

	public boolean equals(NSPCity other){	
		return this.x == other.getX() && this.y == other.getY();
	}
	
	
}
