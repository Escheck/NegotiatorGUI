package NSPClasses;


import java.util.ArrayList;
import java.util.HashMap;

import negotiator.AgentID;
import negotiator.issue.Value;

public class ValueNsp1 extends Value {
	
	//A value is an assignment of cities to agents
	//We assume that the UtilitySpace has one Issue, and each assignment of cities is one Value.
	//Currently we assume that a ValueNSP specifies the entire assignment of cities, rather than just those cities that change owner.
	
	HashMap<NSPCity , AgentID> assignment;

	//Constructor
	public ValueNsp1(HashMap<NSPCity , AgentID> _assignment){
		assignment = _assignment;
	}
	
	
	
	public AgentID getOwnerOfCity(int city){
		return assignment.get(city);
	}
	
	public ArrayList<Integer> getCitiesAssignedTo(AgentID agent){
		ArrayList<Integer> cities = new ArrayList<Integer>();
	
		for(int city=0; city<assignment.size(); city++){
			
			if(agent.equals(getOwnerOfCity(city))){
				cities.add(city);
			}
		}
	
	
		return cities;
	}
	
	
}
