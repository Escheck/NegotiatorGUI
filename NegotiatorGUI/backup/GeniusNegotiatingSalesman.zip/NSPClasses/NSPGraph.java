package NSPClasses;

import java.util.ArrayList;
import java.util.HashMap;

import negotiator.AgentID;

public class NSPGraph {

	
	//FIELDS
	int numCities; 	//the number of cities (including home city!)
	
	protected NSPCity homeCity = new NSPCity(0,0);
	protected ArrayList<NSPCity> fixedCities = new ArrayList<NSPCity>();
	protected ArrayList<NSPCity> interChangeableCities = new ArrayList<NSPCity>();
	
	
	HashMap<NSPCity , AgentID> assignment;
	
	
	//CONSTRUCTORS
	public NSPGraph(){
		//Default constructor
	}
	
	public NSPGraph(ArrayList<NSPCity> fix_cities, ArrayList<NSPCity> int_cities, HashMap<NSPCity , AgentID> _assignment){
		
		interChangeableCities = int_cities;
		fixedCities = fix_cities;	
		
		assignment = _assignment;
	}
	
	
	

	//GETTERS AND SETTERS
	public double getDistance(NSPCity c1, NSPCity c2){
		
		int dX = c1.getX() - c2.getX();
		int dY = c1.getY() - c2.getY();
		
		return Math.sqrt(dX*dX + dY*dY);
		
	}
	

}
