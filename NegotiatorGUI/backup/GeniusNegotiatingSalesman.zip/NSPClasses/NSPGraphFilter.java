package NSPClasses;

import java.util.ArrayList;

import negotiator.AgentID;

public final class NSPGraphFilter {

	//This class gives a specific agent access to the NSPGraph object.
	//It hides the fixed cities of all other agents, so the agent cannot access secret information.
	
	
	AgentID myID;
	private NSPGraph theGraph;
	
	NSPGraphFilter(NSPGraph _theGraph, AgentID _myID){
		theGraph = _theGraph;
		myID = _myID;
	}
	//TODO: are we sure that a user cannot create a new instance of this object with id of another agent, and hence access secret information??
	
	

	
	//Returns the AgentID of the agent that owns the given city
	public AgentID getOwnerOfCity(NSPCity city){
		return theGraph.assignment.get(city);
	}
	

	
	//Returns the home city
	public NSPCity getHomeCity(){
		return theGraph.homeCity;
	}
	
	
	//Returns my fixed cities
	public ArrayList<NSPCity> getMyFixedCities(){
		ArrayList<NSPCity> cities = new ArrayList<NSPCity>();

		for(NSPCity city : theGraph.fixedCities){
			
			if(myID.equals(getOwnerOfCity(city))){
				cities.add(city);
			}
		}	
	
		return cities;
	}
	
	
	//Returns my interchangeable cities
	public ArrayList<NSPCity> getMyInterchangeableCities(){
		return getInterchangeableCitiesAssignedTo(myID);
	}
	
	
	//Returns the interchangeable cities assigned to given agent.
	public ArrayList<NSPCity> getInterchangeableCitiesAssignedTo(AgentID agent){
		
		ArrayList<NSPCity> cities = new ArrayList<NSPCity>();

		for(NSPCity city : theGraph.interChangeableCities){
			
			if(agent.equals(getOwnerOfCity(city))){
				cities.add(city);
			}
		}
	
	
		return cities;
	}
	
	
}
