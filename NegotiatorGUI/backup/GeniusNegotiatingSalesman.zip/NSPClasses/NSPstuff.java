package NSPClasses;

import java.util.ArrayList;


/**
 * 
 * Just a temporary class to put all the NSP functionality.
 * We will decide later where to put this functions.
 * 
 * 
 * @author ddejonge
 *
 */
public class NSPstuff {

	static ArrayList<NSPCity> myCities = new ArrayList<NSPCity>();
	static boolean _isset = false;
	
	public static void addEvaluationValue(double val){
		
		if(val < 0){return;}
		
		_isset = true;
		
		int x = (int)Math.floor(val/100);
		int y = (int)(100 * (val/100 - (double)Math.floor(val/100)));
		
		myCities.add(new NSPCity(x, y));
		
		
	}
	
	
	
	public static boolean isset(){
		return _isset;
	}
	
	public static double calculateUtility(){
		
		//Calculate the TSP here!
		
		_isset = false;
		return 0;
	}
	
	
	
}
